package com.yxjn.myapp.util.ftp;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;
import org.apache.commons.pool.PoolableObjectFactory;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class FTPClientFactory implements PoolableObjectFactory<FTPClient> {

	private static final Logger LOGGER = Logger.getLogger(FTPClientFactory.class);

	@Value("${ftp.host}")
	private String host;

	@Value("${ftp.port}")
	private int port;

	@Value("${ftp.username}")
	private String username;

	@Value("${ftp.password}")
	private String password;

	@Value("${ftp.clientTimeout}")
	private int clientTimeout;

	@Value("${ftp.connectTimeout}")
	private int connectTimeout;

	@Value("${ftp.encoding}")
	private String encoding;

	@Value("${ftp.bufferSize}")
	private int bufferSize;

	@Value("${ftp.passiveMode}")
	private boolean passiveMode;

	// 制造一个对象
	public FTPClient makeObject() throws Exception {
		final FTPClient ftpClient = new FTPClient();
		ftpClient.setConnectTimeout(connectTimeout);
		try {
			ftpClient.connect(host, port);
			final int reply = ftpClient.getReplyCode();
			if (!FTPReply.isPositiveCompletion(reply)) {
				ftpClient.disconnect();
				LOGGER.warn("FTPServer refused connection");
				return null;
			}
			final boolean result = ftpClient.login(username, password);
			if (!result) {
				throw new Exception(
						"ftpClient登陆失败! userName:" + username + " ; password:" + password);
			}
			ftpClient.setFileType(FTP.BINARY_FILE_TYPE);//文件类型
			ftpClient.setControlEncoding(encoding);
			ftpClient.setBufferSize(bufferSize);
			if (passiveMode) {
				//这个方法的意思就是每次数据连接之前，ftp client告诉ftp server开通一个端口来传输数据
				ftpClient.enterLocalPassiveMode();
			}
			// 设置客户端操作超时
			ftpClient.setSoTimeout(clientTimeout);
		} catch (final Exception e) {
			LOGGER.error("ftp池工厂创建对象失败", e);
		}
		return ftpClient;
	}

	// 销毁一个对象
	public void destroyObject(final FTPClient ftpClient) throws Exception {
		try {
			if (ftpClient != null && ftpClient.isConnected()) {
				ftpClient.logout();
			}
		} catch (final Exception e) {
			LOGGER.error("ftp池工厂销毁对象失败", e);
		} finally {
			// 注意,一定要在finally代码中断开连接，否则会导致占用ftp连接情况
			try {
				if (ftpClient != null) {
					ftpClient.disconnect();
				}
			} catch (final Exception e) {
				LOGGER.error("ftp池工厂断开连接失败", e);
			}
		}
	}

	// 验证一个对象是否还可用
	public boolean validateObject(final FTPClient ftpClient) {
		try {
			return ftpClient.sendNoOp();
		} catch (final Exception e) {
			throw new RuntimeException("Failed to validate client: " + e, e);
		}
	}

	public void activateObject(final FTPClient obj) throws Exception {

	}

	public void passivateObject(final FTPClient obj) throws Exception {

	}

}
