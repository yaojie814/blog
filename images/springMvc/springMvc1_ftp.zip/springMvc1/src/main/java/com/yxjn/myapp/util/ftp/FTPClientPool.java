package com.yxjn.myapp.util.ftp;

import java.util.NoSuchElementException;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;

import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.pool.ObjectPool;
import org.apache.commons.pool.PoolableObjectFactory;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

//初始化ftp池
@Component
class InitFtpClientPool implements InitializingBean {

	@Autowired
	private FTPClientPool pool;

	public void afterPropertiesSet() throws Exception {
		pool.initPool();
	}

}

@Component
public class FTPClientPool implements ObjectPool<FTPClient> {

	private static final Logger LOGGER = Logger.getLogger(FTPClientPool.class);

	// 池工厂
	@Autowired
	private FTPClientFactory factory;

	// 池中对象默认大小
	@Value("${ftp.defaultpoolsize}")
	private int defaultpoolsize;

	// 存放对象的队列
	private static BlockingQueue<FTPClient> pool;

	// 初始化池中的对象
	public void initPool() throws Exception {
		// 阻塞队列
		pool = new ArrayBlockingQueue<FTPClient>(defaultpoolsize);
		for (int i = 0; i < defaultpoolsize; i++) {
			 addObject();
		}
		LOGGER.info("FtpClientPool init success");
	}

	// 客户端从池中借出一个对象
	public FTPClient borrowObject() throws Exception, NoSuchElementException, IllegalStateException {
		final FTPClient client = pool.poll();// 这边不能用take()。take是同步方法，当没有可用对象时，会卡死在这里
		if (client == null) {
			addObject();
			return borrowObject();
		} else if (!factory.validateObject(client)) {// 验证不通过
			// 池中移除无效的对象
			invalidateObject(client);
			addObject();
			return borrowObject();
		}
		return client;
	}

	// 客户端归还一个对象到池中
	public void returnObject(final FTPClient client) throws Exception {
		// 当对象不为空，归还池中；但是在3s内不能归还队列，销毁
		if (client != null && !pool.offer(client, 3, TimeUnit.SECONDS)) {
			factory.destroyObject(client);
		}
	}

	// 使对象在池中失效
	public void invalidateObject(final FTPClient client) throws Exception {
		// 移除无效的客户端
		pool.remove(client);
	}

	// 添加对象到池
	public void addObject() throws Exception, IllegalStateException, UnsupportedOperationException {
		pool.offer(factory.makeObject(), 3, TimeUnit.SECONDS);
	}

	public int getNumIdle() throws UnsupportedOperationException {
		return 0;
	}

	public int getNumActive() throws UnsupportedOperationException {
		return 0;
	}

	public void clear() throws Exception, UnsupportedOperationException {

	}

	// 关闭对象池，清理内存释放资源等
	public void close() throws Exception {
		while (pool.iterator().hasNext()) {
			final FTPClient client = pool.take();// 同步方法，直到取到为止
			factory.destroyObject(client);
		}
	}

	// 需要一个工厂来制造池中的对象
	@SuppressWarnings("deprecation")
	public void setFactory(final PoolableObjectFactory<FTPClient> factory)
			throws IllegalStateException, UnsupportedOperationException {
	}

}
