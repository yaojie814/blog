package com.yxjn.myapp.service.async;

import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

@Component
public class TestAsync {

	@Async
	public void test() {
		try {
			Thread.sleep(10000);
			System.out.println("异步等10s执行");
		} catch (final InterruptedException e) {
			e.printStackTrace();
		}
	}
}
