/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT China Mobile (SuZhou) Software Technology Co.,Ltd. 2017
 *******************************************************************************
 *----------------------------------------------------------------------------*/
package com.yxjn.myapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.yxjn.myapp.dao.DemoDao;
import com.yxjn.myapp.entity.DemoEntity;
import com.yxjn.myapp.entity.Pager;

@Service
public class DemoService {

	@Autowired
	private DemoDao demoDao;

	@Value("${test.test1}")
	private int test1;

	public void addOne(final DemoEntity demo) {
		demoDao.addOne(demo);
	}

	public List<DemoEntity> queryList() {
		return demoDao.queryList();
	}

	public void addList(final List<DemoEntity> demos) {
		demoDao.addList(demos);
	}

	public void remove(final String id) {
		System.out.println("xx");
		demoDao.remove(id);
	}

	public void removeIn(final List<String> ids) {
		demoDao.removeIn(ids);
	}

	public void modify(final DemoEntity demo) {
		demoDao.modify(demo);
	}

	public DemoEntity queryOne(final String id) {
		return demoDao.queryOne(id);
	}

	/**
	 * 事务测试
	 */
	@Transactional
	public void transaction() {
		final DemoEntity demo = new DemoEntity();
		demo.setName("Lili");
		demo.setIntro("Lili is also age 18!");
		addOne(demo);
		Integer.parseInt("ss");
		addOne(demo);
	}

	public Pager<DemoEntity> queryPage(final Pager<DemoEntity> pager) {
		final List<DemoEntity> demos = demoDao.queryPage(pager);

		pager.setResult(demos);
		pager.setTotal(demoDao.count());
		pager.setEndNo();

		return pager;
	}

	/**
	 * 测试只在spring配置文件中引入的属性文件
	 */
	public void testValue() {
		System.out.println(test1);
	}
}
