package com.yxjn.myapp.util.ftp;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.commons.net.ftp.FTPClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class MyFTPClient {

	private static final Logger LOGGER = LoggerFactory.getLogger(MyFTPClient.class);

	@Autowired
	private FTPClientPool pool;

	//上传文件
	public void uploadFile(final String fileName, final String absPath, final InputStream in) {
		final FTPClient ftpClient = getFTPClient();
		LOGGER.debug("FTP上传中。。。");
		try {
			// 创建目录
			createDirectory(ftpClient, absPath);
			// 更改目录
			ftpClient.changeWorkingDirectory(absPath);
			// 上传
			final boolean uploadFlag = ftpClient.storeFile(fileName, in);

			if (!uploadFlag) {
				throw new RuntimeException("Fail to upload file. uploadFlag is false,ReplyCode is "
						+ ftpClient.getReplyCode() + " , ReplyString is " + ftpClient.getReplyString());
			}

		} catch (final Exception e) {
			LOGGER.error("Fail to upload file, exception message is :" + e);
			throw new RuntimeException("Fail to upload file.");
		} finally {
			if (in != null) {
				try {
					in.close();
				} catch (final IOException e) {
					LOGGER.error("Fail to close inputStream, exception message is :" + e);
				}
			}
			returnFTPClient(ftpClient);
		}
		LOGGER.debug("FTP上传结束。。。");
	}

	// 直接下载
	public void download(final String absPath, final OutputStream out) {

		final FTPClient ftpClient = getFTPClient();
		LOGGER.debug("FTP获取中。。。");
		try {
			System.out.println(ftpClient.printWorkingDirectory());
			ftpClient.retrieveFile(absPath, out);
		} catch (final Exception e) {
			LOGGER.error("Fail to retrieve file, exception message is :" + e);
			throw new RuntimeException("Fail to retrieve file.");
		} finally {
			returnFTPClient(ftpClient);
		}
		LOGGER.debug("FTP获取结束。。。");
	}

	// 获取下载流
	public InputStream getFileInputStream(final String absPath) {

		final FTPClient ftpClient = getFTPClient();
		InputStream in = null;
		LOGGER.debug("FTP获取中。。。");
		try {
			in = ftpClient.retrieveFileStream(absPath);
		} catch (final Exception e) {
			LOGGER.error("Fail to retrieve file, exception message is :" + e);
			throw new RuntimeException("Fail to retrieve file.");
		} finally {
			returnFTPClient(ftpClient);
		}
		LOGGER.debug("FTP获取结束。。。");
		return in;
	}

	private FTPClient getFTPClient() {
		FTPClient client = null;
		try {
			client = pool.borrowObject();
		} catch (final Exception e) {
			LOGGER.error("获取连接池中的FTPClient异常, exception message is : " + e);
			throw new RuntimeException("获取连接池中的FTPClient异常.");
		}
		return client;
	}

	private void returnFTPClient(final FTPClient client) {
		try {
			pool.returnObject(client);
		} catch (final Exception e) {
			LOGGER.error("归还连接池中的FTPClient异常, exception message is : " + e);
			throw new RuntimeException("归还连接池中的FTPClient异常.");
		}
	}

	private void createDirectory(final FTPClient ftpClient, final String path) {

		try {
			final String separator = "/";
			int index = 0;
			while (index < path.length()) {
				final int pos = path.indexOf(separator, index);
				if (pos == -1) {
					if (!ftpClient.changeWorkingDirectory(path)) {
						ftpClient.makeDirectory(path);
					}
					break;
				}
				index = pos + 1;
				if (!ftpClient.changeWorkingDirectory(path.substring(0, pos))) {
					ftpClient.makeDirectory(path.substring(0, pos));
				}
			}
		} catch (final Exception e) {
			LOGGER.error("Fail to create directory, exception message is :" + e);
			throw new RuntimeException("Fail to create directory.");
		}

	}

}
