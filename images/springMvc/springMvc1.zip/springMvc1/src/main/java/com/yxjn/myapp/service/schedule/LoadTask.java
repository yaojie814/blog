package com.yxjn.myapp.service.schedule;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;


public class LoadTask implements Job {

	public void execute(JobExecutionContext arg0) throws JobExecutionException {
		System.out.println("定时任务！");
	}

}
