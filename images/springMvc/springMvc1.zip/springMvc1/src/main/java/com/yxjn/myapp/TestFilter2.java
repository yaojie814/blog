package com.yxjn.myapp;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class TestFilter2 implements Filter {

	public void destroy() {
		System.out.println("过滤器2[TestFilter]destroy......");
	}

	public void doFilter(final ServletRequest req, final ServletResponse res,
			final FilterChain chain) throws IOException, ServletException {
		//拦截器之前先进行这一步
		System.out.println("过滤器2[TestFilter]doFilter......1");
		chain.doFilter(req, res);
	}

	public void init(final FilterConfig arg0) throws ServletException {
		//启动就执行这一步
		System.out.println("过滤器2[TestFilter]init.....");
	}

}
