/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT China Mobile (SuZhou) Software Technology Co.,Ltd. 2017
 *******************************************************************************
 *----------------------------------------------------------------------------*/
package com.yxjn.myapp.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.yxjn.myapp.entity.DemoEntity;
import com.yxjn.myapp.entity.Pager;

@Repository
public interface DemoDao {

	public void addOne(DemoEntity demo);

	public List<DemoEntity> queryList();

	public void addList(List<DemoEntity> demos);

	public void remove(String id);

	public void removeIn(List<String> ids);

	public void modify(DemoEntity demo);

	public DemoEntity queryOne(String id);

	public List<DemoEntity> queryPage(Pager<DemoEntity> pager);

	public int count();

}
