package com.yxjn.myapp;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * 拦截器
 *
 */
public class TestInterceptor1 implements HandlerInterceptor {

	//在DispatcherServlet 渲染了对应的视图之后执行。这个方法的主要作用是用于进行资源清理工作的。
	public void afterCompletion(final HttpServletRequest arg0,
			final HttpServletResponse arg1, final Object arg2, final Exception arg3)
			throws Exception {
		System.out.println("拦截器1[TestInterceptor]afterCompletion------------4");
	}

	//它会在DispatcherServlet 进行视图返回渲染之前被调用，所以我们可以在这个方法中对Controller 处理之后的ModelAndView 对象进行操作。
	public void postHandle(final HttpServletRequest arg0, final HttpServletResponse arg1,
			final Object arg2, final ModelAndView arg3) throws Exception {
		System.out.println("拦截器1[TestInterceptor]postHandle----------3");
	}

	public boolean preHandle(final HttpServletRequest arg0, final HttpServletResponse arg1,
			final Object arg2) throws Exception {
		System.out.println("拦截器1[TestInterceptor]preHandle---------1,进入程序-----2");
		//false 就到此止步，true 进行下一步2
		return true;
	}

}
