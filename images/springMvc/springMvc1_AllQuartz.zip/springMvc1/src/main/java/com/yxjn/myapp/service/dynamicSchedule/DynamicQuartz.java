package com.yxjn.myapp.service.dynamicSchedule;

import java.util.Collection;
import java.util.Date;
import java.util.HashMap;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.quartz.CronScheduleBuilder;
import org.quartz.CronTrigger;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.TriggerBuilder;
import org.quartz.TriggerKey;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

@Component
class QuartzInit implements InitializingBean {

	@Resource
	private DynamicQuartz dynamicQuartz;

	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("=======动态定时器=初始化运行======");
		dynamicQuartz.addOrUpdateQuartz();
	}

}

@Component
public class DynamicQuartz {

	private static final Logger logger = Logger.getLogger(DynamicQuartz.class);

	@Resource
	private Scheduler scheduler;

	public void addOrUpdateQuartz() {
		try {
			addOrUpdate();
		} catch (final SchedulerException e) {
			logger.error("错误", e);
		}
	}

	private void addOrUpdate() throws SchedulerException {
		final HashMap<String, ScheduleJob> jobMap = new HashMap<String, ScheduleJob>();
		for (int i = 0; i < 2; i++) {
			final ScheduleJob job = new ScheduleJob();
			job.setJobId("10001" + i);
			job.setJobName("data_import" + i);
			job.setJobGroup("dataWork");
			job.setJobStatus("1");
			job.setCronExpression("0/" + getInt() + " * * * * ?");
			job.setDesc("定时任务描述");
			jobMap.put(job.getJobGroup() + "_" + job.getJobName(), job);
		}
		// schedulerFactoryBean 由spring创建注入
		// final Scheduler scheduler = schedulerFactoryBean.getScheduler();
		// 这里获取任务信息数据
		final Collection<ScheduleJob> jobList = jobMap.values();
		for (final ScheduleJob job : jobList) {
			final TriggerKey triggerKey = TriggerKey.triggerKey(job.getJobName(), job.getJobGroup());
			// 获取trigger，即在spring配置文件中定义的 bean id="myTrigger"
			CronTrigger trigger = (CronTrigger) scheduler.getTrigger(triggerKey);
			// 不存在，创建一个
			if (null == trigger) {
				final JobDetail jobDetail = JobBuilder.newJob(QuartzJobFactory.class)
						.withIdentity(job.getJobName(), job.getJobGroup()).build();
				jobDetail.getJobDataMap().put("scheduleJob", job);
				// 表达式调度构建器
				final CronScheduleBuilder scheduleBuilder = CronScheduleBuilder.cronSchedule(job.getCronExpression());
				// 按新的cronExpression表达式构建一个新的trigger
				trigger = TriggerBuilder.newTrigger().withIdentity(job.getJobName(), job.getJobGroup())
						.withSchedule(scheduleBuilder).startAt(new Date(new Date().getTime() + 10000)).build();
				scheduler.scheduleJob(jobDetail, trigger);
			} else {
				// Trigger已存在，那么更新相应的定时设置
				// 表达式调度构建器
				final CronScheduleBuilder scheduleBuilder = CronScheduleBuilder.cronSchedule(job.getCronExpression());
				// 按新的cronExpression表达式重新构建trigger
				trigger = trigger.getTriggerBuilder().withIdentity(triggerKey).withSchedule(scheduleBuilder)
						.startAt(new Date(new Date().getTime() + 10000)).build();
				// 按新的trigger重新设置job执行，这个时候Job中ScheduleJob是不变的
				scheduler.rescheduleJob(triggerKey, trigger);
			}
		}
	}

	private static int getInt() {
		return (int) (Math.random() * 10) + 1;
	}

}
