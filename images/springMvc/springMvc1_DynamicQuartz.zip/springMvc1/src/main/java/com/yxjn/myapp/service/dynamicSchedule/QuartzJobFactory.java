package com.yxjn.myapp.service.dynamicSchedule;

import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

/**
 * 定时任务运行工厂类
 */
@DisallowConcurrentExecution  //线程唯一
public class QuartzJobFactory implements Job {

    @Override
    public void execute(final JobExecutionContext context) throws JobExecutionException {
        System.out.println("任务成功运行");
        final ScheduleJob scheduleJob = (ScheduleJob)context.getMergedJobDataMap().get("scheduleJob");
        //这里根据每个ScheduleJob的jobStatus，jobName，jobGroup等做操作
        System.out.println("任务名称 = [" + scheduleJob.getJobName() + "]");
    }
}