package com.yxjn.myapp;

import java.util.HashMap;
import java.util.Map;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

@ControllerAdvice
public class ControllerExceptionHandler {

	//可以定义多个方法捕捉不同的异常
    @ExceptionHandler({ Exception.class })
    @ResponseBody
    public Object exceptionHandler(final Exception e) {
    	final Map<String, String> map = new HashMap<String, String>();
    	map.put("key", "统一异常捕捉成功");
    	map.put("status", "500");
        System.out.println(e);
        return map;
    }

}
