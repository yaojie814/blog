package com.yxjn.myapp.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.yxjn.myapp.entity.DemoEntity;
import com.yxjn.myapp.entity.Pager;
import com.yxjn.myapp.service.DemoService;
import com.yxjn.myapp.service.async.TestAsync;
import com.yxjn.myapp.service.dynamicSchedule.DynamicQuartz;

@Controller
@RequestMapping("/demo")
public class DemoController {

	private static final Logger logger=Logger.getLogger(DemoController.class);

	@Autowired
	private DemoService demoservice;

	@Autowired
	private TestAsync testAsync;

	@Resource
	private DynamicQuartz dynamicQuartz;

	@ResponseBody
	@RequestMapping(value = "/quartz.do")
	public String quartz() {
		dynamicQuartz.addOrUpdateQuartz();
		logger.info("这是我打印的log日志ok");
		return "ok";
	}

	@ResponseBody
	@RequestMapping(value = "/index.do")
	public String index() {
		testAsync.test();
		logger.info("这是我打印的log日志");
		return "首页";
	}

	@RequestMapping("/showMessage.do")
	public ModelAndView showMessage() {
		final ModelAndView mv = new ModelAndView("showMessage");
		mv.addObject("message", "这是jsp页面的jstl");
		return mv;
	}

	@RequestMapping("/addOne.do")
	public ModelAndView addOne(){
		final DemoEntity demo = new DemoEntity();
		demo.setName("xiaoming");
		demo.setIntro("xiaoming is age 18!");
		demoservice.addOne(demo);
		final List<DemoEntity> demos = demoservice.queryList();
		final ModelAndView mv = new ModelAndView("demo");
		mv.addObject("demos", demos);
		return mv;
	}

	@RequestMapping("/addList.do")
	public ModelAndView addList(){
		final List<DemoEntity> demosIn = new ArrayList<DemoEntity>();
		final DemoEntity demo1 = new DemoEntity();
		demo1.setName("xiaoming");
		demo1.setIntro("xiaoming is age 18!");
		demosIn.add(demo1);
		final DemoEntity demo2 = new DemoEntity();
		demo2.setName("小红");
		demo2.setIntro("小红 is age 21!");
		demosIn.add(demo2);
		demoservice.addList(demosIn);
		final List<DemoEntity> demos = demoservice.queryList();
		final ModelAndView mv = new ModelAndView("demo");
		mv.addObject("demos", demos);
		return mv;
	}

	@RequestMapping("/remove.do")
	public ModelAndView remove(final String id){
//		String id = "61";
		demoservice.remove(id);
		final List<DemoEntity> demos = demoservice.queryList();
		final ModelAndView mv = new ModelAndView("demo");
		mv.addObject("demos", demos);
		return mv;
	}

	@RequestMapping("/removeIn.do")
	public ModelAndView removeIn(){
		final List<String> ids = new ArrayList<String>();
		ids.add("64");
		ids.add("66");
		demoservice.removeIn(ids);
		final List<DemoEntity> demos = demoservice.queryList();
		final ModelAndView mv = new ModelAndView("demo");
		mv.addObject("demos", demos);
		return mv;
	}

	@RequestMapping("/modify.do")
	public ModelAndView modify(){
		final DemoEntity demo = new DemoEntity();
		demo.setId("1");
		demo.setName("xiaoming");
		demo.setIntro("xiaoming is age 20!");
		demoservice.modify(demo);
		final List<DemoEntity> demos = demoservice.queryList();
		final ModelAndView mv = new ModelAndView("demo");
		mv.addObject("demos", demos);
		return mv;
	}

	@RequestMapping("/queryOne.do")
	public ModelAndView queryOne(final String id){
//		String id = "67";
		final DemoEntity demo = demoservice.queryOne(id);
		final ModelAndView mv = new ModelAndView("demo");
		mv.addObject("demos", demo);
		return mv;
	}

	@ResponseBody
	@RequestMapping("/queryPage.do")
	public Pager<DemoEntity> queryPage(){
		final int page = 1;
		final int size = 3;
		Pager<DemoEntity> pager = new Pager<DemoEntity>(page, size);
		pager = demoservice.queryPage(pager);
		return pager;
	}

	@RequestMapping("/queryList.do")
	public ModelAndView queryList(){
		final List<DemoEntity> demos = demoservice.queryList();
		final ModelAndView mv = new ModelAndView("demo");
		mv.addObject("demos", demos);
		return mv;
	}

	@RequestMapping("/transaction.do")
	public ModelAndView transaction(){
		demoservice.transaction();

		final List<DemoEntity> demos = demoservice.queryList();
		final ModelAndView mv = new ModelAndView("demo");
		mv.addObject("demos", demos);
		return mv;
	}
}