package com.yxjn.myapp.service.schedule;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.stereotype.Component;

@Component
public class LoadTask implements Job {

	@Override
	public void execute(final JobExecutionContext arg0) throws JobExecutionException {
		System.out.println("定时任务！");
	}

}
