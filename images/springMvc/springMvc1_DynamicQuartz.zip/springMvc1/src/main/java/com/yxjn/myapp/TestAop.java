package com.yxjn.myapp;

import java.util.List;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Value;

//描述切面类
@Aspect
public class TestAop {

	@Value("${url}")
	private String url;

	/*
	 * 定义一个切入点
	 */
	@Pointcut("execution(* com.yxjn.myapp.service.DemoService.remove*(..))")
	public void excudeService(){}

	/**
	 * 主要执行
	 * @param thisJoinPoint
	 */
	@Around("excudeService()")
	public void twiceAsOld(final ProceedingJoinPoint thisJoinPoint){
		try {
			System.out.println("切面,方法前" + url);//第一执行
			//先执行@Before方法
			thisJoinPoint.proceed();//再执行方法
			System.out.println("切面,方法后");//再执行
			//再执行@After(excudeService())方法（多个按顺序下去）
			//再执行@After(自定义切点)方法
		} catch (final Throwable e) {
			e.printStackTrace ();
		}
	}

	/*
	 * 通过连接点切入
	 */
	@Before("execution(* remove*(..)) &&" + "args(id,..)") //切所有remove开始方法 参数id
	public void twiceAsOld1(final String id){
		System.out.println ("切面@Before。。。。id==" + id);
	}

	/*
	 * 切面后处理方法
	 */
	@After("execution(* com.yxjn.myapp.service.DemoService.remove*(..)) &&" + "args(ids,..)") //切DemoService下remove方法 参数名ids
	public void aopAfter(final List<String> ids){
		System.out.println ("切面@After。。。。ids==" + ids);
	}

	/*
	 * 切面后处理方法
	 */
	@After("excudeService()")
	public void aopAfter(){
		System.out.println ("切面@After。。。。2。");
	}
}