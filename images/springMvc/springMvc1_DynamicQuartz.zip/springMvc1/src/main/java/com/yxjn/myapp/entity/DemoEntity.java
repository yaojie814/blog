package com.yxjn.myapp.entity;


public class DemoEntity {

	private String id;

	private String name;

	private String intro;

	public String getIntro() {
		return intro;
	}

	public void setIntro(final String intro) {
		this.intro = intro;
	}

	public String getName() {
		return name;
	}

	public void setName(final String name) {
		this.name = name;
	}

	public String getId() {
		return id;
	}

	public void setId(final String id) {
		this.id = id;
	}

}
