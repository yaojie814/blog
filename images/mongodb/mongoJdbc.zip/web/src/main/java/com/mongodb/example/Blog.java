package com.mongodb.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Blog {

    static void print(final String name, final ResultSet res) throws SQLException {
        System.out.println(name);
        while (res.next()) {
            System.out.println(
                    "\t" + res.getInt("num") +
                    "\t" + res.getString("title") +
                    "\t" + res.getObject("tags")
            );
        }
    }

    public static void main(final String args[]) throws SQLException, ClassNotFoundException {

        Class.forName("com.mongodb.jdbc.MongoDriver");

        final Connection c = DriverManager.getConnection("mongodb://127.0.0.1:27017/test");

        final Statement st = c.createStatement();
        st.executeUpdate("drop table blogposts");

        final PreparedStatement ps = c.prepareStatement("insert into blogposts ( title , tags , num ) values ( ? , ? , ? )");
        ps.setString(1, "first post!");
        ps.setObject(2, new String[]{"fun", "eliot"});
        ps.setInt(3, 1);
        ps.executeUpdate();

        ps.setString(1, "wow - this is cool");
        ps.setObject(2, new String[]{"eliot", "bar"});
        ps.setInt(3, 2);
        ps.executeUpdate();
        ps.close();

        print("num should be 1 ", st.executeQuery("select * from blogposts where tags='fun'"));
        print("num should be 2 ", st.executeQuery("select * from blogposts where tags='bar'"));
    }

}
