package com.mongodb.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class HelloWorld {

    static void print(final String name, final ResultSet rs) throws SQLException {
        System.out.println(name);
        while (rs.next()) {
            System.out.println(
                    "\t" + rs.getString("name") +
                    "\t" + rs.getInt("age") +
                    "\t" + rs.getObject(0)
            );
        }
    }

    public static void main(final String args[]) throws SQLException, ClassNotFoundException {

        Class.forName("com.mongodb.jdbc.MongoDriver");

        // The format of the URI is:
        // jdbc:mongodb://[username:password@]host1[:port1][,host2[:port2],...[,hostN[:portN]]][/[database][?options]]
        final Connection c = DriverManager.getConnection("jdbc:mongodb://10.139.8.207:27031,10.139.8.207:27032/diameter_test");

        final Statement stmt = c.createStatement();

        // drop old table
        stmt.executeUpdate("DROP TABLE people");

        // insert some data
        stmt.executeUpdate("INSERT INTO people (name, age) VALUES ('Eliot' , 30)");
        stmt.executeUpdate("INSERT INTO people (name, age) VALUES ('Sara'  , 12)");
        stmt.executeUpdate("INSERT INTO people (name, age) VALUES ('Jaime' , 28)");

        final String baseSQL = "SELECT name, age FROM people";

        // query
        print("not sorted", stmt.executeQuery(baseSQL));
        print("where", stmt.executeQuery(baseSQL + " WHERE name = 'Eliot'"));
        print("sorted by age", stmt.executeQuery(baseSQL + " ORDER BY age"));
        print("sorted by age desc", stmt.executeQuery(baseSQL + " ORDER BY age DESC LIMIT 2,1"));

        // update
        stmt.executeUpdate("UPDATE people SET age = 32 WHERE name = 'Jaime'");
        print("after update", stmt.executeQuery(baseSQL + " ORDER BY age DESC"));
    }

}
