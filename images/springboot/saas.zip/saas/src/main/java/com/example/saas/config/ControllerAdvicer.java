package com.example.saas.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * @author yaoj
 * @create 2019-12-17 18:56
 **/
@RestControllerAdvice
@Slf4j
public class ControllerAdvicer {

    @ExceptionHandler(RuntimeException.class)
    public String handleBusinessException(RuntimeException e) {
        log.error("业务异常", e);
        return e.getMessage();
    }
}