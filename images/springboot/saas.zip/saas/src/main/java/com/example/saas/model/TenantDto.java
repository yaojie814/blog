package com.example.saas.model;

import lombok.Data;

@Data
public class TenantDto {
    private String url;

    private String username;

    private String password;
}