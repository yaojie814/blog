package com.example.saas.controller;

import com.alibaba.fastjson.JSONObject;
import com.example.saas.dao.UserDao;
import com.example.saas.model.UserDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@RestController
public class UserController {

    @Autowired
    private UserDao userDao;

    @PostMapping("/login")
    public String login(HttpServletRequest request, @RequestBody UserDto dto) {

        UserDto userDto = userDao.findByUsernameAndPassword(dto);
        if (userDto != null) {
            request.getSession().setAttribute("tenant", request.getHeader("tenant"));
            return JSONObject.toJSONString(userDto);
        } else {
            return "无此用户";
        }
    }

    @PostMapping("/add")
    @Transactional
    public String add() {

        UserDto dto1 = new UserDto();
        dto1.setId("11");
        dto1.setUsername("user1");
        dto1.setPassword("root");
        userDao.insertOne(dto1);
//        int a = 1/0;
        UserDto dto2 = new UserDto();
        dto2.setId("22");
        dto2.setUsername("user2");
        dto2.setPassword("root");
        userDao.insertOne(dto2);
        return "success";
    }
}