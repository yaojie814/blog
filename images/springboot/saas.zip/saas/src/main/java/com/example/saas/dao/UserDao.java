package com.example.saas.dao;

import com.example.saas.model.UserDto;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface UserDao {

    @Select("select id,username,password from USER where username = #{username} and password = #{password}")
    UserDto findByUsernameAndPassword(UserDto dto);

    @Insert("insert into USER(id,username,password) values (#{id}, #{username}, #{password})")
    //自增返回主键@Options(useGeneratedKeys=true, keyProperty="id", keyColumn="id")
    void insertOne(UserDto dto);
}