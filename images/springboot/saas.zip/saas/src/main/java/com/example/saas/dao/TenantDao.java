package com.example.saas.dao;

import com.example.saas.model.TenantDto;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface TenantDao {

    @Select("select url,username,password from MASTER_TENANT where tenant = #{tenant}")
    TenantDto findByTenant(@Param("tenant") String tenant);
}