package com.example.saas.config;

import com.example.saas.dao.TenantDao;
import com.example.saas.model.TenantDto;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;

@Configuration
public class InterceptorConfig extends WebMvcConfigurerAdapter {

    @Autowired
    private TenantInterceptor tenantInterceptor;

    @Override
    public void addInterceptors(InterceptorRegistry registry){
        registry.addInterceptor(tenantInterceptor).addPathPatterns("/**");
    }
}

@Component
class TenantInterceptor implements HandlerInterceptor {

    @Autowired
    private TenantDao tenantDao;

    @Autowired
    private DynamicRoutingDataSource dynamicRoutingDataSource;

    @Value("${spring.datasource.driverClassName}")
    private String driverClassName;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        String url = request.getServletPath();
        String tenant;
        if ("/login".equals(url) || "/register".equals(url)) {
            // 登录的时候获取下租户数据库信息
            tenant = request.getHeader("tenant");
        } else {
            // 其他所有接口走session
            Object tenantObj = request.getSession().getAttribute("tenant");
            if (tenantObj == null) {
                throw new RuntimeException("租户未登录");
            }
            tenant = tenantObj.toString();
        }
        if (StringUtils.isNotBlank(tenant)) {
            if (!dynamicRoutingDataSource.existDataSource(tenant)) {
                //搜索默认数据库，去注册租户的数据源，下次进来直接session匹配数据源
                TenantDto dto = tenantDao.findByTenant(tenant);
                if (dto == null) {
                    throw new RuntimeException("无此租户");
                }
                Map<String, Object> map = new HashMap<>();
                map.put("driverClassName", driverClassName);
                map.put("url", dto.getUrl());
                map.put("username", dto.getUsername());
                map.put("password", dto.getPassword());
                dynamicRoutingDataSource.addDataSource(tenant, map);
            }
        }
        // 为了单次请求，多次连接数据库的情况，这里设置localThread，AbstractRoutingDataSource的方法去获取设置数据源
        DynamicDataSourceContextHolder.setDataSourceKey(tenant);
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
                           ModelAndView modelAndView) throws Exception {
        // 请求结束删除localThread
        DynamicDataSourceContextHolder.clearDataSourceKey();
    }
}